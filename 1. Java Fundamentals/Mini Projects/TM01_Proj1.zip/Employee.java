
public class Employee {

    public int id;
    public String name;
    public String joinDate;
    public String designationCode;
    public String dept;
    public int basic;
    public int hra;
    public int it;

    public Employee(int id, String name, String joinDate, String designationCode, String dept, int basic, int hra,
            int it) {
        this.id = id;
        this.name = name;
        this.joinDate = joinDate;
        this.designationCode = designationCode;
        this.dept = dept;
        this.basic = basic;
        this.hra = hra;
        this.it = it;
    }

    public Employee() {
    }

    public String getDesignationCode() {
        return designationCode;
    }

    public String getDesignation(char code) {

        switch (code) {
            case 'e':
                return "Engineer";
            case 'c':
                return "Consultant";
            case 'k':
                return "Clerk";
            case 'r':
                return "Receptionist";
            case 'm':
                return "Manager";
            default:
                return "invalid";
        }
    }

    public Employee getEmployeeById(int id) {
        if (this.id == id) {
            return this;
        }
        return null;
    }

    public int getSalary(int basic, int hra, int it, char code) {
        int da = 0;
        switch (code) {
            case 'k':
                da = 12000;
                break;
            case 'c':
                da = 32000;
                break;
            case 'e':
                da = 20000;
            case 'r':
                da = 15000;
                break;
            case 'm':
                da = 40000;
                break;
            default:
                da = 0;
                break;
        }

        return (basic + hra - it) + da;
    }

    @Override
    public String toString() {

        return "Emp No.\tEmp Name\tDepartment\tDesignation\tSalary\n" +
                this.id + "\t" + this.name + "\t\t" + this.dept + "\t\t"
                + this.getDesignation(this.designationCode.charAt(0)) + "\t\t" +
                this.getSalary(this.basic, this.hra, this.it, this.designationCode.charAt(0));
    }

}