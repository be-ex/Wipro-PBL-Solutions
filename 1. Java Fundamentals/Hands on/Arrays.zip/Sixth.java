import java.util.Arrays;

public class Sixth {
    public static void main(String[] args) {
        int arr[]={65, 99, 11, 58, 53, 33, 100, 43, 67, 54, 1, 0, 25};
        Arrays.sort(arr);
        for (int i = 0; i < arr.length; i++) {
            System.out.print(arr[i]+" ");
        }
    }
}
