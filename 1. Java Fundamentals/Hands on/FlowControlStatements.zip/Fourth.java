public class Fourth {
    public static void main(String[] args) {
        char character1 = args[0].charAt(0);
        char character2 = args[1].charAt(0);
        if (character1 > character2) {
            System.out.println(character2 + "," + character1);
        } else {
            System.out.println(character1 + "," + character2);
        }
    }
}
