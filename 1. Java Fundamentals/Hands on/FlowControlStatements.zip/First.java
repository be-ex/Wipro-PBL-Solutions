class First{
    public static void main(String[] args) {
        int num=10;
        if(num<0){
            System.out.println("negative");
        }else if(num==0){
            System.out.println("zero");
        }else{
            System.out.println("positive");
        }
    }
}